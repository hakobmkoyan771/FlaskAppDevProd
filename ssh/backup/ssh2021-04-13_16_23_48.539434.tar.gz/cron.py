from ssh import * 
import schedule
#import time
from apscheduler.schedulers.blocking import BlockingScheduler


main()
scheduler = BlockingScheduler()
scheduler.add_job(main, 'interval', seconds=5)
scheduler.start()
#schedule.every().hour.do(job)

while True:
    schedule.run_pending()
    time.sleep(20)



	
