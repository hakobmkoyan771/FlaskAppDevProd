#!/usr/bin/pytihon3
from crontab import CronTab  


cron = CronTab(user=True) 
task = cron.new(command='bash ./ssh.sh') 

task.minute.on(1)

True == task.is_valid()  
cron.write()
