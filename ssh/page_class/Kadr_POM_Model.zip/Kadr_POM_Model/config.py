def get_page_link():
    return "https://www.kadrtour.com/en"

