from test_kadr_hotels_page import *
import os


def find_function_name(file_path):
    all_test_case = []
    f = open(file_path,"r")
    read_file = f.readlines()
    f.close()
    for line in read_file:
        if line.startswith("def"):
            line_split = line[4:]
            line_end_split = line_split[:-2]
            all_test_case.append(line_end_split)
    return all_test_case


def get_input_case_name(page_link, input_file_name):
    input_file_name = str(input_file_name).replace("'" , "").replace("'", "")
    input_file_name = str(input_file_name).replace("[" , "").replace("]", "")
    file_name = "test_kadr_hotels_page.py"
    if input_file_name in file_name:
        file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),  "{}".format(input_file_name))
        all_function_name_list = find_function_name(file_path)
        return all_function_name_list

    else:
        all_test_folder_path =  os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_kadr_hotels_page.py")
        function_name_list = find_function_name(all_test_folder_path)
        return function_name_list

def test_runner(page_link, input_file_name):
    test_folder_path = "/home/erida-employee/Desktop/ssh/page_class/Kadr_POM_Model/test_kadr_hotels_page.py"
    case_name = get_input_case_name(page_link, input_file_name)
    for i in input_file_name:
        serch_test = i + "(page_link)"
        try:
            if serch_test in case_name:
                eval(serch_test)
        except TypeError:
            print("This test name is not found: ")

def run_all_test_case(input_file_name, page_link):
    run_case_name = get_input_case_name(page_link, input_file_name)
    for test in run_case_name:
        eval(test)

def main():    
    get_path("/home/erida-employee/Desktop/ssh/page_class/Kadr_POM_Model/Test")
    page_link = get_page_link()
    input_file_name = input("Enter name of input file: ")
    input_file_name = input_file_name.split()
    file_name = "test_kadr_hotels_page.py"
    if file_name in input_file_name:
        run_all_test_case(input_file_name, page_link)
    else:
        test_runner(page_link, input_file_name)


if __name__ == '__main__':
    main()


