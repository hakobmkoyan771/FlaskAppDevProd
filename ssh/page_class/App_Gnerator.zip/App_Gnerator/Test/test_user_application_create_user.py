from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

import sys
import os
import time

def get_path(path):
    os.chdir(path)
    sys.path.insert(0,path)


get_path("/home/erida-employee/Desktop/ssh/page_class/App_Gnerator/Page")
get_path("/home/erida-employee/Desktop/ssh/page_class/App_Gnerator")

from user_application_create_user import UserApplicationCreateUserPage
from config import *



class UserApplicationCreateUserPageLocators:
    locator_login_send_keys = (By.XPATH, '/html/body/div/div[1]/div/div/div/div/div/div/div/form/div[1]/div/div[1]/div')
    locator_password_send_keys = (By.XPATH, '/html/body/div/div[1]/div/div/div/div/div/div/div/form/div[2]/div/div[1]/div[1]')
    locator_click_login_button = (By.XPATH, "/html/body/div/div[1]/div/div/div/div/div/div/div/form/div[5]/button/span")
    locator_click_user_button = (By.XPATH, '//*[@id="app"]/div[1]/nav/div[1]/div[2]/div[3]/div/a')
    locator_click_add_new_button = (By.XPATH, '//*[@id="app"]/div[1]/main/div/div[2]/header/div/div[3]/button/span') 
    locator_fill_full_name = (By.XPATH, '//*[@id="app"]/div[3]/div/div/div[2]/div/form/div[1]/div[1]/div/div/div[1]/div')
    locator_click_role_name = (By.XPATH, '//*[@id="app"]/div[3]/div/div/div[2]/div/form/div[1]/div[2]/div/div/div[1]/div[1]/div/div/i')
    locator_select_role_name = (By.XPATH, '//*[@id="list-item-160-1"]/div/div')
    locator_fill_business_email = (By.XPATH, '//*[@id="app"]/div[3]/div/div/div[2]/div/form/div[2]/div[2]/div/div/div[1]/div')
    locator_fill_password = (By.XPATH, '//*[@id="app"]/div[3]/div/div/div[2]/div/form/div[2]/div[3]/div/div/div[1]/div')
    locator_click_on_the_save_button = (By.XPATH, '//*[@id="app"]/div[3]/div/div/div[3]/button[2]/span[1]')


class TestUserApplicationCreateUserPage(UserApplicationCreateUserPage):
    def click_on_the_save_button(self):
        return self.find_element(UserApplicationCreateUserPageLocators.locator_click_on_the_save_button,time=2).click()

    def fill_password(self):
        element = self.find_element(UserApplicationCreateUserPageLocators.locator_fill_password,time=2)
        element.click()
        search = element.find_element_by_tag_name("input")
        search.send_keys("tamarapapikyantest.org", Keys.ENTER)

    def fill_business_email(self):
        element = self.find_element(UserApplicationCreateUserPageLocators.locator_fill_business_email,time=2)
        element.click()
        search = element.find_element_by_tag_name("input")
        search.send_keys("tamarapapikyan@test.org", Keys.ENTER)

    def select_role_name(self):
        return self.find_element(UserApplicationCreateUserPageLocators.locator_select_role_name,time=2).click()

    def click_role_name(self):
        return self.find_element(UserApplicationCreateUserPageLocators.locator_click_role_name,time=2).click()

    def fill_full_name(self):
        fill_field = self.find_element(UserApplicationCreateUserPageLocators.locator_fill_full_name,time=2)
        name_input = fill_field.find_element_by_tag_name("input")
        name_input.send_keys("test_user_app", Keys.ENTER)

    def click_add_new_button(self):
        return self.find_element(UserApplicationCreateUserPageLocators.locator_click_add_new_button,time=2).click()

    def click_user_button(self):
        return self.find_element(UserApplicationCreateUserPageLocators.locator_click_user_button,time=2).click()

    def send_login(self):
        login_field = self.find_element(UserApplicationCreateUserPageLocators.locator_login_send_keys,time=2)
        search_input = login_field.find_element_by_tag_name("input")
        search_input.send_keys("test-admin@test.org", Keys.ENTER)

    def send_password(self):
        login_field = self.find_element(UserApplicationCreateUserPageLocators.locator_password_send_keys,time=2)
        search_input = login_field.find_element_by_tag_name("input")
        search_input.send_keys("test-admintest.org", Keys.ENTER)

    def click_on_the_login_button(self):
        return self.find_element(UserApplicationCreateUserPageLocators.locator_click_login_button,time=2).click()
    

