from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys

import sys
import os
import time

def get_path(path):
    os.chdir(path)
    sys.path.insert(0,path)


get_path("/home/erida-employee/Desktop/ssh/page_class/App_Gnerator/Page")
get_path("/home/erida-employee/Desktop/ssh/page_class/App_Gnerator")

from user_application_create_role import UserApplicationCreateRolePage
from config import *



class UserApplicationCreateRolePageLocators:
    locator_login_send_keys = (By.XPATH, '/html/body/div/div[1]/div/div/div/div/div/div/div/form/div[1]/div/div[1]/div')
    locator_password_send_keys = (By.XPATH, '/html/body/div/div[1]/div/div/div/div/div/div/div/form/div[2]/div/div[1]/div[1]')
    locator_click_login_button = (By.XPATH, "/html/body/div/div[1]/div/div/div/div/div/div/div/form/div[5]/button/span")
    locator_click_role_button = (By.XPATH, '//*[@id="app"]/div[1]/nav/div[1]/div[2]/div[4]/div/a')
    locator_click_add_new_button = (By.XPATH, '//*[@id="app"]/div/main/div/div[2]/header/div/div[3]/button/span')
    locator_fill_role_name = (By.XPATH, '//*[@id="app"]/div[3]/div/div/div[2]/div/form/div/div[1]/div/div/div[1]/div')
    locator_click_on_the_button_save = (By.XPATH, '//*[@id="app"]/div[3]/div/div/div[3]/button[2]/span[1]')


class TestUserApplicationCreateRolePage(UserApplicationCreateRolePage):
    def click_on_the_button_save(self):
        return self.find_element(UserApplicationCreateRolePageLocators.locator_click_on_the_button_save,time=2).click()

    def fill_role_name(self):
        element = self.find_element(UserApplicationCreateRolePageLocators.locator_fill_role_name,time=2)
        element.click()
        search = element.find_element_by_tag_name("input")
        search.send_keys("Moderator", Keys.ENTER)

    def click_add_new_button(self):
        return self.find_element(UserApplicationCreateRolePageLocators.locator_click_add_new_button,time=2).click()

    def click_role_button(self):
        return self.find_element(UserApplicationCreateRolePageLocators.locator_click_role_button,time=2).click()

    def send_login(self):
        login_field = self.find_element(UserApplicationCreateRolePageLocators.locator_login_send_keys,time=2)
        search_input = login_field.find_element_by_tag_name("input")
        search_input.send_keys("test-admin@test.org", Keys.ENTER)

    def send_password(self):
        login_field = self.find_element(UserApplicationCreateRolePageLocators.locator_password_send_keys,time=2)
        search_input = login_field.find_element_by_tag_name("input")
        search_input.send_keys("test-admintest.org", Keys.ENTER)

    def click_on_the_login_button(self):
        return self.find_element(UserApplicationCreateRolePageLocators.locator_click_login_button,time=2).click()
    

